import logo from './logo.svg';
import './App.css';
import App1 from './Components/App1';

function App() {
  return (
    <div className="App">
         <App1/>
    </div>
  );
}

export default App;
