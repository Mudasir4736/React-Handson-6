import React from 'react';

const Contact = () => {
    return (
        <div>
           <img src="https://wpforms.com/wp-content/uploads/2021/02/tune-contact-us-page-examples.png" alt="" />
        </div>
    );
}

export default Contact;
