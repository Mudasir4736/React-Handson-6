import React from 'react';

const Home = () => {
    return (
        <div>
            <img src="https://assets.hongkiat.com/uploads/getting-started-react-js/react-home.jpg?newedit" alt=""  width='100%'/>
        </div>
    );
}

export default Home;
