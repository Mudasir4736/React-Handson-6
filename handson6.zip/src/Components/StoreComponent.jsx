import React, { createContext } from "react";

const store=createContext()

export default store;